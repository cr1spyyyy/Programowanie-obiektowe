public interface Jedzie{
    void jedz(String nazwa);
}
