public interface Plywa {
    void plyn(String nazwa);
}
