public class Samolot implements  Lata{
    @Override
    public void lec(String nazwa) {
        System.out.println(nazwa+" lata");
    }
}
