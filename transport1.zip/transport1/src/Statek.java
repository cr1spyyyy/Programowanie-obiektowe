public class Statek implements Plywa{
    @Override
    public void plyn(String nazwa) {
        System.out.println(nazwa +" tonie");
    }
}
