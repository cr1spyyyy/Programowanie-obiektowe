public interface Lata {
    void lec(String nazwa);
}
