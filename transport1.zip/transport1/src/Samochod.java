public class Samochod implements Jedzie{

    @Override
    public void jedz(String nazwa) {
        System.out.println(nazwa + " jedzie");
    }
}
