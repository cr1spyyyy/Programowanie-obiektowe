public abstract class Ptak extends Zwierze implements Latanie{
    void jedz(){
        System.out.println("ptaki poluja na jedzonk");
    }
    void wydalaj(){
        System.out.println("ptak ci daje na auto");
    }
}
