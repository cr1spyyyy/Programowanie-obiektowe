public interface Latanie {
    void lec();
    void wyladuj();

}
