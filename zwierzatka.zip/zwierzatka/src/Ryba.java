public abstract class Ryba extends Zwierze implements Plywanie{
    void jedz(){
        System.out.println("rybka je");
    }
    void wydalaj(){
        System.out.println("ryba wydala");
    }
}
