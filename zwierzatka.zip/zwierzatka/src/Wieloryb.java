public class Wieloryb extends Ryba{
    public void plyn(){
        System.out.println("Wieloryb plynie");
    }
    public void wynurz(){
        System.out.println("Wieloryb sie wynurza");
    }
    public void zanurz(){
        System.out.println("Wieloryb sie zanurza");
    }
}
