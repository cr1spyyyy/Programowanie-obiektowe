public abstract class Zwierze {
    abstract void jedz();
    abstract void wydalaj();
}
