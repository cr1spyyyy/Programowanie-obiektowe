public class Bocian extends Ptak{
    public void lec(){
        System.out.println("Bocian leci");
    }
    public void wyladuj(){
        System.out.println("Bocian laduje");
    }
}
