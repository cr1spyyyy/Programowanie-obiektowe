public interface MetodaPlatnosci {
    void zaplac(double kwota);
}
